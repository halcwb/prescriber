// Create a file system object to delete the target file
var fs;
fs = new ActiveXObject("Scripting.FileSystemObject");

WScript.Echo("Created FS object");

var file = WScript.Arguments(1);
if (fs.FileExists(file)) {
    fs.DeleteFile(file);
}

WScript.Echo("Deleted file: " + file);

// Download the file from the url
var WinHttpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
var url = WScript.Arguments(0);

WScript.Echo("Downloading file: " + url);

WinHttpReq.Open("GET", url, /*async=*/false);
WinHttpReq.Send();


// Save the file to the target file
BinStream = new ActiveXObject("ADODB.Stream");
BinStream.Type = 1;
BinStream.Open();
BinStream.Write(WinHttpReq.ResponseBody);
BinStream.SaveToFile(file);

WScript.Echo("Saved to file: " + file);